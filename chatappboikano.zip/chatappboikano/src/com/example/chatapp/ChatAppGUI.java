/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;





/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
        // === GLOBAL UI SETTINGS ===
        Color lightGreen = new Color(144, 238, 144); // light green
        Color blueBorder = Color.BLUE;
        Color blackText = Color.BLACK;

        UIManager.put("OptionPane.background", lightGreen);
        UIManager.put("Panel.background", lightGreen);
        UIManager.put("OptionPane.messageForeground", blackText);
        UIManager.put("OptionPane.border", new LineBorder(blueBorder, 4));
        UIManager.put("Button.background", Color.WHITE);
        UIManager.put("Button.foreground", blackText);

        // === COMBINED LOGO + WELCOME POPUP ===
        JPanel logoPanel = new JPanel(new BorderLayout());
        logoPanel.setBackground(lightGreen);
        logoPanel.setBorder(new LineBorder(blueBorder, 5));

        JLabel logoLabel = new JLabel("💬 BMQuickChat", SwingConstants.CENTER);
        logoLabel.setFont(new Font("Arial", Font.BOLD, 32));
        logoLabel.setForeground(blackText);

        JLabel sloganLabel = new JLabel("“Connecting minds, one message at a time.” ✨", SwingConstants.CENTER);
        sloganLabel.setFont(new Font("Arial", Font.ITALIC, 16));
        sloganLabel.setForeground(blackText);

        logoPanel.add(logoLabel, BorderLayout.CENTER);
        logoPanel.add(sloganLabel, BorderLayout.SOUTH);

        JOptionPane.showMessageDialog(null, logoPanel, "Welcome to BMQuickChat 💚", JOptionPane.PLAIN_MESSAGE);

        // === LOGIN & REGISTRATION LOGIC ===
        login login = new login();

        // === REGISTRATION ===
        while (true) {
            JOptionPane.showMessageDialog(null, "📝 Create your BMQuickChat account:");

            String username = JOptionPane.showInputDialog(null, "Enter a username (must contain '_' and be no more than 5 characters):");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Enter a password (min 8 chars, 1 capital, 1 number, 1 special char):");
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(null, "Enter cellphone (e.g. ‪+27838968976‬):");
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage);

            if (regMessage.equals("Registration successful.")) break;
        }

        // === LOGIN ===
        boolean loggedIn = false;
        String loggedUsername = null;

        while (!loggedIn) {
            JOptionPane.showMessageDialog(null, "🔑 Login to continue");
            String username = JOptionPane.showInputDialog(null, "Username:");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Password:");
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg);

            if (ok) {
                loggedIn = true;
                loggedUsername = username.trim();
            }
        }

        JOptionPane.showMessageDialog(null, "🌟 Welcome back, " + loggedUsername + "! Let’s get chatting.");

        // === NUMBER OF MESSAGES ===
        int messagesToEnter = 0;
        while (messagesToEnter <= 0) {
            String nm = JOptionPane.showInputDialog(null, "💭 How many messages would you like to send?");
            if (nm == null) return;
            try {
                messagesToEnter = Integer.parseInt(nm.trim());
                if (messagesToEnter <= 0)
                    JOptionPane.showMessageDialog(null, "Please enter a positive number.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
            }
        }

        List<Message> allMessages = new ArrayList<>();
        boolean quit = false;

        while (!quit) {
            String menu = "📋 Menu:\n1️⃣ Send messages\n2️⃣ View last message\n3️⃣ Exit app";
            String choice = JOptionPane.showInputDialog(null, menu);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1":
                    if (allMessages.size() >= messagesToEnter) {
                        JOptionPane.showMessageDialog(null, "⚠ Message limit reached (" + messagesToEnter + "). You can’t send more.");
                        break;
                    }

                    int remaining = messagesToEnter - allMessages.size();
                    JOptionPane.showMessageDialog(null, "🗨 You can still send " + remaining + " message(s).");

                    for (int i = 0; i < remaining; i++) {
                        String recipient = JOptionPane.showInputDialog(null,
                                String.format("Enter recipient for message %d (include +27):", allMessages.size() + 1));
                        if (recipient == null) break;

                        String messageText = JOptionPane.showInputDialog(null, "Type your message (max 250 chars):");
                        if (messageText == null) break;

                        // Validate message length
                        if (messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null,
                                    "Message too long! Max is 250 characters.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            i--;
                            continue;
                        }

                        JOptionPane.showMessageDialog(null, "📤 Sending your message...");

                        Message m = new Message(allMessages.size(), recipient.trim(), messageText);
                        String actionResult = m.sendMessageViaDialog();
                        JOptionPane.showMessageDialog(null, actionResult);

                        if (m.getStatus() == Message.Status.STORED) {
                            try {
                                Message.storeMessagesToJson(
                                        Collections.singletonList(m),
                                        System.getProperty("user.home") + "/stored_messages.json");
                                JOptionPane.showMessageDialog(null,
                                        "✅ Message saved to JSON at:\n" + System.getProperty("user.home") + "/stored_messages.json");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null, "❌ Failed to store message: " + ex.getMessage());
                            }
                        }

                        JOptionPane.showMessageDialog(null, m.printMessageDetails());
                        allMessages.add(m);

                        if (allMessages.size() >= messagesToEnter) {
                            JOptionPane.showMessageDialog(null, "📦 You’ve reached your message limit (" + messagesToEnter + ").");
                            break;
                        }
                    }

                    int totalSent = Message.returnTotalMessages(allMessages);
                    JOptionPane.showMessageDialog(null, "📊 Total messages sent so far: " + totalSent);
                    break;

                case "2":
                    if (allMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent yet.");
                    } else {
                        Message last = allMessages.get(allMessages.size() - 1);
                        JOptionPane.showMessageDialog(null, "🕐 Last message sent:\n" + last.printMessageDetails());
                    }
                    break;

                case "3":
                    quit = true;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "❓ Invalid option. Choose 1, 2, or 3.");
            }
        }

        JOptionPane.showMessageDialog(null,
                "👋 Thank you for using BMQuickChat!\nStay connected, stay inspired 💚");
    }
}