/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author boite
 */
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    // --- Username Tests ---
    @Test
    public void testUsernameCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertTrue(login.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        Login login = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertFalse(login.checkUserName());
    }

    // --- Password Tests ---
    @Test
    public void testPasswordMeetsComplexity() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testPasswordFailsComplexity() {
        Login login = new Login("kyl_1", "password", "Kyle", "Smith", "+27839698976");
        assertFalse(login.checkPasswordComplexity());
    }

    // --- Cell Number Tests ---
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "08966553");
        assertFalse(login.checkCellPhoneNumber());
    }

    // --- Login Tests ---
    @Test
    public void testLoginSuccessful() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        assertFalse(login.loginUser("wrong", "wrong"));
    }

    // --- Login Status Messages ---
    @Test
    public void testLoginStatusSuccessful() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        String expected = "Welcome Kyle, Smith it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginStatusFailed() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith", "+27839698976");
        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus("wrong", "wrong"));
    }
}

